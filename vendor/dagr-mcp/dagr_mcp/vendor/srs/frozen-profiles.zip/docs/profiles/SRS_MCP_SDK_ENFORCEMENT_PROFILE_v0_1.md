# SRS MCP SDK Enforcement Profile v0.1

## 1. Identifier and scope

The profile identifier is `srs.mcp.sdk_enforcement.v0.1`. It defines SRS receipts for an MCP admission boundary that observes a requested tool call and, when admitted, the semantic result returned at that boundary.

This profile uses the admission-first linked-outcome model. It does not attest to transport bytes, background-task completion, remote-server internals, host logging posture, or underlying handler execution when intervening middleware can satisfy a request.

## 2. Common envelope requirements

Every receipt MUST conform to the current SRS envelope and the SRS Signed Receipt Profile v0.1. These fields are required for every receipt under this profile:

- `receipt_version`
- `profile_id`
- `profile_version`
- `receipt_id`
- `receipt_type`
- `receipt_kind`
- `boundary_type`
- `protocol_binding`
- `subject_ref`
- `issuer_id`
- `runtime_instance_id`
- `boundary_id`
- `logical_call_id`
- `issued_at`
- `artifact_classes_covered`
- `artifact_classes_excluded`
- `attestation_limits`
- `extensions`
- `receipt_signature`

`profile_id` MUST equal `srs.mcp.sdk_enforcement`. `profile_version` MUST equal `v0.1`. `receipt_type` MUST equal `sdk_enforcement`, `boundary_type` MUST equal `mcp_tool_call`, and `protocol_binding` MUST equal `mcp`.

## 3. Raw-content-excluding rule

Receipt envelopes and profile-owned sinks MUST reject raw governed content. Receipts MUST carry references and digests only. They MUST NOT carry raw prompts, transcripts, request bodies, tool arguments, tool results, response bodies, headers, credentials, access tokens, private file paths, or equivalent content under renamed fields.

The private-reference marker set MUST include `/Users/`, `/home/`, `/private/var`, `C:\\`, `~/garp-`, and `~/arcs-anchor`. A conforming emitter MUST reject those markers in references intended for external verification.

`artifact_classes_excluded` MUST include `raw_prompt`, `raw_output`, `raw_tool_arguments`, and `raw_tool_result`.

## 4. Admission receipt

An admission receipt is always required. `receipt_kind` MUST equal `admission` and `disposition` MUST be one of:

- `admitted`
- `refused`
- `deferred_for_review`

The receipt MUST include:

- `requested_tool_name`
- `tool_resolution_status`
- `argument_digest`
- `policy_pack_id`
- `policy_pack_version`

`tool_resolution_status` MUST be `not_observed` when the binding cannot observe tool resolution. `resolved_tool_ref` MUST be absent in that case. Admission establishes policy evaluation over the requested identifier and arguments, not successful registration or resolution of a tool.

A refused admission receipt is terminal and MUST NOT have a linked outcome receipt. A deferred admission receipt is terminal and MUST include `review_object_ref` and `retry_contract` equal to `retry_after_approval`. There is no separate deferred receipt kind.

When durable review-object creation fails, the binding MUST emit a terminal refused admission receipt with `reason_code` equal to `review_object_creation_failed`, `review_object_ref` absent, and no linked outcome. The handler MUST NOT execute.

## 5. Outcome receipt

An outcome receipt exists only after an admitted receipt. It MUST carry:

- `receipt_kind`: `outcome`
- `admission_receipt_ref`
- `outcome`

`outcome` MUST be one of:

- `result_returned`
- `error_returned`
- `exception`
- `task_submitted`
- `indeterminate`

The admission and outcome receipts MUST share `logical_call_id`, `boundary_id`, `runtime_instance_id`, `subject_ref`, and the relevant policy identifiers.

`result_returned` MUST include `result_digest` computed from `fastmcp.tool_result.v1`. `error_returned` uses the same projection and digest but records that the returned `ToolResult` carried an error result. `exception` MAY carry an exception class identifier and MUST NOT carry an exception message by default.

## 6. Required attestation limits

Every receipt MUST contain a non-empty `attestation_limits` array.

A `result_returned` or `error_returned` receipt MUST include this limit:

> The receipt establishes the request, admission disposition, and semantic result returned at the configured boundary. It does not independently establish that the underlying tool body executed for this invocation, because middleware such as caches may satisfy a call without handler execution.

A `task_submitted` receipt MUST include this limit:

> The receipt establishes admission and submission to the configured task backend. It does not establish execution or completion.

A proxy-boundary receipt MUST state that it attests only to what crossed and returned through the proxy boundary.

## 7. Receipt-gap semantics

An admitted receipt without a linked terminal outcome is an open admission and a detectable custody gap. It is not proof that execution failed.

When outcome finalization fails, a conforming binding SHOULD emit a typed `receipt_gap` operational event through an independent alert or emergency-spool path. The binding MUST NOT claim that an indeterminate outcome receipt exists unless that receipt was durably accepted.

## 8. Cancellation and timeout fields

An `indeterminate` outcome MAY use:

- `request_cancelled`
- `execution_state_unknown`
- `result_not_delivered`

A flat `cancelled` outcome is prohibited. Cancellation or timeout MUST NOT be interpreted as proof that no side effect occurred.

## 9. Reserved identifiers

The profile reserves these canonical identifiers for use when applicable:

- `issuer_id`
- `runtime_instance_id`
- `tenant_id`
- `workspace_id`
- `actor_ref`
- `subject_ref`
- `policy_pack_id`
- `policy_pack_version`
- `profile_id`
- `profile_version`
- `parent_receipt_ref`
- `source_record_refs`
- `review_object_ref`
- `artifact_ref`
- `projection_ref`
- `retention_class`
- `custody_sink_ref`
- `boundary_id`
- `logical_call_id`
- `requested_tool_name`
- `resolved_tool_ref`
- `tool_resolution_status`

## 10. `fastmcp.tool_result.v1`

The projection input is a FastMCP `ToolResult`. The projection MUST map:

- Python `content` to JSON `content`
- Python `structured_content` to JSON `structuredContent`
- Python `meta` to JSON `_meta`
- Python `is_error` to JSON `isError`

The projection MUST encode all four members. `None` MUST be encoded as JSON `null`; members MUST NOT be omitted. Pydantic values MUST be dumped in JSON mode with aliases enabled and `exclude_none` disabled. Unknown fields present on content-block models MUST remain committed when the model exposes them through its JSON dump.

The resulting data model MUST be I-JSON compatible and RFC 8785 canonicalizable. NaN, Infinity, integers outside the interoperable range, unpaired surrogates, and non-serializable `_meta` values MUST fail projection with a typed error. The pre-JCS data model is the exact four-member JSON object above. Its RFC 8785 bytes are hashed with SHA-256 and represented as `sha256:<lowercase-hex>`.

The durable receipt MUST store only the resulting digest, not the projection itself.

## 11. Middleware-order consequences

The declared installation order is: error handling, authentication and authorization, rate limiting, DAGR admission middleware, caching, retry, response transforms, and the tool handler.

Refusals before the DAGR boundary are not DAGR receipts. Cache hits are receipted as `result_returned`, not as proof of handler execution. Retries inside the boundary appear as one logical call. An outer attempt log is security telemetry and is not an SRS admission receipt.

## 12. Refusal reason-code vocabulary

The initial refusal reason-code vocabulary includes:

- `policy_refused`
- `unknown_tool_fail_closed`
- `required_sink_unavailable`
- `review_object_creation_failed`
- `pre_execution_receipt_failure`

Implementations MAY add namespaced reason codes. Unnamespaced additions require a profile revision.
